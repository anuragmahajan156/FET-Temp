const id= new URLSearchParams(window.location.search).get('id');
const container = document.querySelector(".more");

const renderdetails = async () => {
    let uri = "http://localhost:3000/blogs/" + id;
    const res = await fetch(uri);
    const blogs = await res.json();
    if(blogs.flag==true){
    var template =`
    <div class="container-fluid">
      <h3>Title:${blogs.title}</h3>
      <div>
      <h3>Image:</h3>
      <div class="col-sm-12"><img class="blogImg" src="${blogs.imgpath}" width="250px"; height="250px"/></div>
      </div>
      <h3>Blog Text:</h3><textarea class="blogText" disabled>${blogs.text}</textarea>
      <div>
            <i id="${blogs.id}" class="fa fa-thumbs-up icon" onclick="onClickforlike(this,this.id,event)"><p class="fa-likes">${blogs.likes}</p></i>
      <div>
      <button class="btn btn-dark" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
      Comment
      </button>
      <div class="collapse" id="collapseExample">
      <textarea class="blogText2" id="txtcomment"></textarea>
      <div>
      <button class="btn btn-dark" type="button" id="${blogs.id}" onclick="addcomment(${blogs.id})">

      Post
      </button></div>
      </div>
      </div>
      </div>
      <div class="comment"><button class="btn btn-outline-dark" onclick="displaycomment(${blogs.id})">Show all comments</button></div>
       <div id="allcomments"></div>`}
    else{
        var template = `
        <div class="container-fluid">
        <h3>Title:${blogs.title}</h3>
        <div>
        <h3>Blog Text:</h3><textarea class="blogText" disabled >${blogs.text}</textarea>
        <div>
        <div>
            <i id="${blogs.id}" class="fa fa-thumbs-up icon" onclick="onClickforlike(this,this.id,event)"><p class="fa-likes">${blogs.likes}</p></i>
        </div>
        <div>
        <button class="btn btn-dark" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
        Comment
        </button>
        <div class="collapse" id="collapseExample">
       <textarea class="blogText2" id="txtcomment"></textarea>
        <div>
        <button class="btn btn-dark" type="button" id="${blogs.id}" onclick="addcomment(${blogs.id})">
        Post
        </button></div>
        </div>
        </div>
        </div>
        <div class="comment"><button class="btn btn-outline-dark" onclick="displaycomment(${blogs.id})">Show all comments</button></div>
        <div id="allcomments"></div>      `
    }

    container.innerHTML = template;
}


window.addEventListener("DOMContentLoaded", () => { renderdetails();
});
//     blogs.forEach((blog) => {
//         if(blog.flag==true){
//         template += `

//         <div class="container-fluid blogs2">
//         <div class="row">
//           <div class="col-md-3">
//             <div class="col-sm-12"><img class="" src="${blog.imgpath}" class="blogImg"/></div>
//           </div>
//           <div class="col-md-9">
//             <div class="col-sm-12"><h4>Title:${blog.title}</h4></div>
//             <div class="col-sm-12"><h4>Category:${blog.category}</h4></div>
//             <div class="catButton">
//                 <button type="button" class="btn btn-outline-dark ">
//                    <a href="displayReadMoreBlog.html?id=${blog.id}" class="read">Read the Blog</a>
//                 </button>
//             </div>
//           </div>
//         </div>
//       </div>
// </div>
//        `}
//        else{
//         template += `

//         <div class="container-fluid blogs2">
//         <div class="row">
//           <div class="col-md-3">
//             <div class="col-sm-12"><img class="" src="../BackEnd/images/image2.jfif" class="blogImg"/></div>
//           </div>
//           <div class="col-md-9">
//             <div class="col-sm-12"><h4>Title:${blog.title}</h4></div>
//             <div class="col-sm-12"><h4>Category:${blog.category}</h4></div>
//             <div class="catButton">
//                 <button type="button" class="btn btn-outline-dark ">
//                    <a href="displayBlog.html" class="read">Read the Blog</a>
//                 </button>
//             </div>
//           </div>
//         </div>
//       </div>
// </div>
//        `
//        }
//     });

//     container.innerHTML = template;
// };



