
var nameRef = document.getElementById("name");
var passwordRef = document.getElementById("password");
var confPasswordRef = document.getElementById("confPassword");
var userName = document.getElementById("emailId");
//const Axios=require("axios");
function validation(){
    if(nameRef.value!=null ){
        document.getElementById("name").style.border="1px solid red";
    }
}
function validation2(){
    if(passwordRef.value!=null){
        document.getElementById("emailId").style.border="1px solid red";
    }
}
function validation3(){
    if(userName.value!=null ){
        document.getElementById("password").style.border="1px solid red";
    }
}
var handleOnClick=(event)=>{
    event.preventDefault();
    if (passwordRef.value === confPasswordRef.value) {
        var user = {
            name: nameRef.value,
            userName: userName.value,
            password: passwordRef.value,
        };
        console.log(user)
        if(user.name!="" && user.userName!="" && user.password!=""){
        $.ajax({
            url: 'http://localhost:3000/users',
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: (response) => {
                let flag2 = true;
                if(response!=null){

                for(let i=0;i<response.length;i++)
                {
                    if(response[i].userName === userName.value)
                    {
                        flag2=false;
                        alert("User Already exists");
                        console.log(flag2);
                        location.href = "../FrontEnd/signup.html";
                        break;
                    }
                }
            }
                //If user does not exists then it will add the user
                if (flag2) {
                    //posting user data to JSON file
                    $.ajax({
                        url: 'http://localhost:3000/users',
                        method: "POST",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify(user),
                        success: function (data) {
                            if(data!=null){
                            console.log("User added");
                            location.href = "../FrontEnd/login.html";
                            alert("User added");
                        }
                        },
                        error: function () {
                            console.log("Errorrrr");
                        },
                        complete: function () {
                            console.log("Completed")

                        }
                    })
                }
            },
            error: function () {
                console.log("Errorrrr");
            },
            complete: function () {
                console.log("Completed")
            }
        })
    }
    else{
        validation();
        validation2();
        validation3();
    }
}
else{
    alert("Password do not match")
}
}




/*
console.log(user);
    $.ajax({
        type: 'POST',
        contentType: 'application/json',
        url: "http://localhost:3000/users",
        data:JSON.stringify(user),
        dataType: "json",
        success: function(resultData) { alert("Save Complete")
                                         console.log(resultData);}

    })
*/
