
var onClickforlike = (element, id, event) => {
    console.log(element + " " + id + " " + event)
    $.ajax({
        type: 'GET',
        contentType: 'application/json',
        url: `http://localhost:3000/blogs?id=${id}`,
        dataType: "json",
        success: (result) => {
            console.log("in get");
            if (result[0] != null) {
                console.log(result[0]);
                const {userid, category, title, imgpath, text, timestamp, likes, comments, flag, likeFlag} = result[0];
                let obj = {
                    userid: userid,
                    category: category,
                    title: title,
                    imgpath: imgpath,
                    text: text,
                    timestamp: timestamp,
                    likes: likes,
                    comments: comments,
                    flag: flag,
                    id: id,
                    likeFlag: likeFlag
                };
                console.log(obj.likeFlag);
                ///console.log(obj);
                if (sessionStorage.getItem("userid") != null) {

                    if (obj.likeFlag === false || obj.likeFlag === true) {
                        obj.likes = obj.likes + 1;
                        obj.likeFlag = true;
                        let firstChild = element.firstChild;
                        firstChild.innerText = obj.likes;
                        element.style.color = "blue";

                    } /*else{ ///(obj.likeFlag === true)
                        obj.likes = obj.likes - 1;
                        obj.likeFlag = false;
                        let firstChild = element.firstChild;
                        firstChild.innerText = obj.likes;
                        element.style.color = "black";
                    }*/



                    $.ajax({
                        url: `http://localhost:3000/blogs/${id}`,
                        type: 'PUT',
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify(obj),
                        success: function (data, textStatus, xhr) {
                            console.log(data);
                        },
                        error: function (xhr, textStatus, errorThrown) {
                            console.log('Error in Operation');
                        }
                    });


                }
            }
        }

    })
}


