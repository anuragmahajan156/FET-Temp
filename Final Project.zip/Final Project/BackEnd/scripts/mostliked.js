

const mostliked=()=>{

    display();
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:3000/blogs?_sort=likes&_order=desc",
        dataType: "json",
        success: (blogs) => {
            console.log("in");
            let display1="";
            var i=0;
            while(i<=2)
            {
                display1+=`
                <div class="col-md-4 col-12 mb-3">
                <div class="card">
                  <img class="img-fluid" alt="100%x280"
                    src="${blogs[i].imgpath}">
                  <div class="card-body">
                    <h4 class="card-title">${blogs[i].title}</h4>
                    <button type="button" class="btn btn-warning"><a href="create.html"
                        style="color: black;">${blogs[i].category}</a></button>
                  </div>
                </div>
              </div>
                     `
              i++;
            }
            //console.log(dis);
            //console.log(document.getElementById("d"));
            document.getElementById("d1").innerHTML=display1; //first row

            let display2="";
            while(i<=5)
            {
                display2+=`
                <div class="col-md-4 col-12 mb-3">
                <div class="card">
                  <img class="img-fluid" alt="100%x280"
                    src="${blogs[i].imgpath}">
                  <div class="card-body">
                    <h4 class="card-title">${blogs[i].title}</h4>
                    <button type="button" class="btn btn-warning"><a href="create.html"
                        style="color: black;">${blogs[i].category}</a></button>
                  </div>
                </div>
              </div>
                     `
              i++;
            }
            document.getElementById("d2").innerHTML=display2;  //for row 2

        }
    });
}

//document.getElementsByTagName("BODY")[0].addEventListener("onload", mostliked);

var display=()=>{
  console.log("here");
  var isLogin=sessionStorage.getItem("userid");
  if(isLogin!=null)
  {
     //document.getElementById("login").style.visibility="none";
     //document.getElementById("signup").style.visibility="none";

     document.getElementById("login").style.display="none";
     document.getElementById("signup").style.display="none";
     
  }
  else{
     
     // document.getElementById("createblog").style.visibility="none";
     // document.getElementById("logout").style.visibility="none";

      document.getElementById("createblog").style.display="none";
      document.getElementById("logout").style.display="none";

  }

}
